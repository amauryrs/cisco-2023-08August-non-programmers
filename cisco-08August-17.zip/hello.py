# define the function "hello"
def hello():
    name = input('Enter your name: ').strip()
    print(f'Hello, {name}!')

# run the function "hello"
hello()


