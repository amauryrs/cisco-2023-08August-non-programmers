name = input('Enter your name: ').strip()
print(f'Hello, {name}!')