import rich

print('This is boring text.')

rich.print('This is [bold red]amazing[/bold red] text.')